from setuptools import setup

setup()
